=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Chepalle Courrèges & Bravado Banshee 900R Vice Beach Custom Pack
Slug        : gta-vi-vice-beach-custom-donk-supercar-pack
Game        : GTA VI
Author      : AsphaltKilla
Version     : v1.9
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
