=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Multi Theft Auto: San Andreas (MTA:SA v1.6) Open-Source Engine
Game        : GTA SA
Author      : CrankHandle
Version     : v1.6.0
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/multitheftauto/mtasa-blue/releases/tag/v1.6.0

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
