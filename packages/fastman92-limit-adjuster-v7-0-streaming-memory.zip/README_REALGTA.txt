=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Fastman92 Limit Adjuster v7.0 — Unlimited IDs, Streaming Memory & Map Bounds
Slug        : fastman92-limit-adjuster-v7-0-streaming-memory
Game        : GTA SA
Author      : DecompileGod
Version     : v7.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
