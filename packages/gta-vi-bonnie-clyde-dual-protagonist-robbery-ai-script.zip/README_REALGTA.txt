=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA VI Bonnie & Clyde Dual-Protagonist Switching & Robbery AI Script
Slug        : gta-vi-bonnie-clyde-dual-protagonist-robbery-ai-script
Game        : GTA VI
Author      : CrankHandle
Version     : v2.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
