=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : DayL Natural Timecycle & Liberty City Volumetric Fog Overhaul
Slug        : dayl-natural-timecycle-liberty-city-volumetric-fog-gta-iv
Game        : GTA IV
Author      : RayTracerIV
Version     : v2.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
