=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Niko Bellic HD Remastered Character Mesh & Russian Leather Jacket Pack
Slug        : niko-bellic-hd-remastered-character-mesh-jacket-pack
Game        : GTA IV
Author      : GroveStLegend
Version     : v2.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
