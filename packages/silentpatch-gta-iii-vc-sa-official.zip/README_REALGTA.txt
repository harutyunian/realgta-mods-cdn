=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : SilentPatch for GTA III, Vice City & San Andreas (CookiePLMonster)
Game        : GTA SA
Author      : CookiePLMonster
Version     : 1.1-BUILD34.1-SA
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/CookiePLMonster/SilentPatch/releases/tag/1.1-BUILD34.1-SA

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
