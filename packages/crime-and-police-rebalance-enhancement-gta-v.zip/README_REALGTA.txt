=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Crime and Police Rebalance & Enhancement (CPR) — Stealth & Dispatch Overhaul
Slug        : crime-and-police-rebalance-enhancement-gta-v
Game        : GTA V
Author      : LeonidaSheriff
Version     : v1.8
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
