=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Claude Speed 4K Leather Jacket, Beta Outfit & Classic Skins Pack
Slug        : claude-speed-4k-leather-jacket-beta-outfit-skins
Game        : GTA III
Author      : GroveStLegend
Version     : v1.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
