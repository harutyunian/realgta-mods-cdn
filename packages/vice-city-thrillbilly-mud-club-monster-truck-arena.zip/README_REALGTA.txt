=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Vice City Thrillbilly Mud Club & Monster Truck Physics Arena
Slug        : vice-city-thrillbilly-mud-club-monster-truck-arena
Game        : GTA VI
Author      : CartoGamer
Version     : v1.3
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
