=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Vice City Social Media Feed & Leonida Man Random Events Pack
Slug        : vice-city-social-media-leonida-man-random-events
Game        : GTA VI
Author      : LeonidaMapper
Version     : v1.2
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
