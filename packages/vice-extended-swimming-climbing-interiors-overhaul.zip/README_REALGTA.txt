=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Vice Extended v2.5 — Swimming, Climbing, New Interiors & 80s Lore Expansion
Slug        : vice-extended-swimming-climbing-interiors-overhaul
Game        : GTA VC
Author      : TommyV_Ret
Version     : v2.5
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
