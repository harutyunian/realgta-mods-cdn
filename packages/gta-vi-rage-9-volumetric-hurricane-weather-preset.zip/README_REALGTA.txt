=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA VI RAGE 9 Volumetric Hurricane & Tropical Storm Weather Preset
Slug        : gta-vi-rage-9-volumetric-hurricane-weather-preset
Game        : GTA VI
Author      : RayTracerIV
Version     : v1.5
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
