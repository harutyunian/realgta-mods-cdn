=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Tommy Vercetti 4K Remastered Suits, Hawaiian Shirt & Crockett Wardrobe
Slug        : tommy-vercetti-4k-remastered-suits-crockett-wardrobe
Game        : GTA VC
Author      : TommyV_Ret
Version     : v2.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
