=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA VI Realistic Weapon Sling, Duffel Bag & Trunk Loadout System
Slug        : gta-vi-realistic-weapon-sling-trunk-loadout-script
Game        : GTA VI
Author      : LeonidaMapper
Version     : v1.8
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
