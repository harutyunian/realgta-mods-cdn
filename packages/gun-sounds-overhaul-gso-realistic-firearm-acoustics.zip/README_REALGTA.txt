=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Gun Sounds Overhaul (GSO) — Realistic Acoustics & Supersonic Crack
Slug        : gun-sounds-overhaul-gso-realistic-firearm-acoustics
Game        : GTA V
Author      : SynthWaveCop
Version     : v2.6
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
