=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Gta Vi Lucia Jason Dual Protagonist Pack
Slug        : gta-vi-lucia-jason-dual-protagonist-pack
Game        : GTA V / SA / IV
Author      : RealGTA Community
Version     : v1.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
