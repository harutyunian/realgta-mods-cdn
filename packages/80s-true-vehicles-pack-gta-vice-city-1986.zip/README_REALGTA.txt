=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : 80s True Vehicles Pack for GTA: Vice City (95 Period-Correct 1986 Cars)
Slug        : 80s-true-vehicles-pack-gta-vice-city-1986
Game        : GTA VC
Author      : SynthWaveCop
Version     : v2.3
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
