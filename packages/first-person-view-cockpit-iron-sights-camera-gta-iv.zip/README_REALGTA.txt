=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : First Person View v1.22 (C2A) — True Cockpit & Iron Sights Camera for GTA IV
Slug        : first-person-view-cockpit-iron-sights-camera-gta-iv
Game        : GTA IV
Author      : ThirteenAG
Version     : v1.22
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
