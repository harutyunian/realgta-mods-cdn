=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : LS Life — Street Economy, Stash Houses & Turf Reputation Script
Slug        : ls-life-street-economy-stash-houses-script-gta-v
Game        : GTA V
Author      : CrankHandle
Version     : v2.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
