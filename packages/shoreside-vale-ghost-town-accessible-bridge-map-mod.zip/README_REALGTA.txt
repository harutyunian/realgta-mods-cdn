=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Shoreside Vale & Ghost Town Accessible Bridge & Interior Expansion
Slug        : shoreside-vale-ghost-town-accessible-bridge-map-mod
Game        : GTA III
Author      : CartoGamer
Version     : v1.2
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
