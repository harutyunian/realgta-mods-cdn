=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Liberty City Lore-Friendly HD Vehicle Pack (120 Remastered Cars)
Slug        : liberty-city-lore-friendly-hd-vehicle-pack-gta-iv
Game        : GTA IV
Author      : MafiaDon
Version     : v1.8
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
