=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Lively World Expansion — Dynamic Roadworks, Car Crashes & Street Events
Slug        : lively-world-expansion-dynamic-street-events-gta-v
Game        : GTA V
Author      : CrankHandle
Version     : v2.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
