=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Pfister Comet S2 Cabrio & Mansory Widebody Custom Add-On Pack
Slug        : pfister-comet-s2-mansory-widebody-addon-pack
Game        : GTA V
Author      : MafiaDon
Version     : v2.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
