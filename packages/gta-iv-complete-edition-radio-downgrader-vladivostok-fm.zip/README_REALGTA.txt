=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA IV Complete Edition Radio Downgrader (Restores Vladivostok FM & Cut OST)
Slug        : gta-iv-complete-edition-radio-downgrader-vladivostok-fm
Game        : GTA IV
Author      : SynthWaveCop
Version     : v2.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
