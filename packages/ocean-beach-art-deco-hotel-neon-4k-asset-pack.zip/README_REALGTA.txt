=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Ocean Beach Art Deco Hotel Neon & Vice Signage 4K Asset Pack
Slug        : ocean-beach-art-deco-hotel-neon-4k-asset-pack
Game        : GTA VI
Author      : CartoGamer
Version     : v1.7
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
