=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Euphoria Ragdoll & Gunplay Physics Overhaul (RDR1 Ballistics Port)
Slug        : gta-iv-euphoria-ragdoll-rdr1-ballistics-overhaul
Game        : GTA IV
Author      : AsphaltKilla
Version     : v2.2
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
