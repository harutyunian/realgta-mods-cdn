=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : SkyGfx III v3.6 — PS2 Trails, Neo Car Reflections & Radiosity for GTA III
Slug        : skygfx-iii-ps2-trails-neo-car-reflections-gta-3
Game        : GTA III
Author      : RayTracerIV
Version     : v3.6
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
