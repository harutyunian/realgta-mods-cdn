=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Open All Interiors v6.2 — 65+ Accessible Los Santos & Blaine County Buildings
Slug        : open-all-interiors-los-santos-blaine-county
Game        : GTA V
Author      : CartoGamer
Version     : v6.2
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
