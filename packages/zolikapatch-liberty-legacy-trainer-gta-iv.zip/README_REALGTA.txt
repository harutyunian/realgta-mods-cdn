=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : ZolikaPatch & Liberty Legacy Trainer for GTA IV Complete Edition
Slug        : zolikapatch-liberty-legacy-trainer-gta-iv
Game        : GTA IV
Author      : ThirteenAG
Version     : v7.6
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
