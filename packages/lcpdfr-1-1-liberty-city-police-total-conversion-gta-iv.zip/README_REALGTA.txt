=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : LCPD First Response (LCPDFR 1.1) — Liberty City Police Total Conversion
Slug        : lcpdfr-1-1-liberty-city-police-total-conversion-gta-iv
Game        : GTA IV
Author      : LeonidaSheriff
Version     : v1.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
