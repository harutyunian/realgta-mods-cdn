=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA: Underground v4.2 — Liberty City, Vice City, Manhunt & Bullworth Map Merge
Slug        : gta-underground-liberty-vice-manhunt-bullworth-map-merge
Game        : GTA SA
Author      : ModderCarl
Version     : Snapshot 4.2
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
