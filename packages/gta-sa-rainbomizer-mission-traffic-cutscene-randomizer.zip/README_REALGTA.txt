=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA SA Rainbomizer v3.1 — Complete Mission, Traffic, Cutscene & Voice Randomizer
Game        : GTA SA
Author      : Parik27_Courier
Version     : v3.2
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/Parik27/SA.Rainbomizer/releases/tag/v3.2

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
