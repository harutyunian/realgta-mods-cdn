=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Enhanced Native Trainer (ENT Update 51) — Vehicle & World Control Suite
Slug        : enhanced-native-trainer-ent-gta-v
Game        : GTA V
Author      : AlexanderBlade_Retro
Version     : Update 51
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
