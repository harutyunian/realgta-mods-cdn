=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Various Pedestrians & Liberty City Traffic Variety Overhaul v2.3
Slug        : liberty-city-pedestrians-traffic-variety-overhaul
Game        : GTA IV
Author      : GroveStLegend
Version     : v2.3
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
