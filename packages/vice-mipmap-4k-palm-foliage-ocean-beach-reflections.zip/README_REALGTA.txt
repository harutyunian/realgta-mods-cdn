=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Vice Mipmap & 4K Palm Foliage + Neon Ocean Beach Reflections Pack
Slug        : vice-mipmap-4k-palm-foliage-ocean-beach-reflections
Game        : GTA VC
Author      : GraphicsGod
Version     : v2.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
