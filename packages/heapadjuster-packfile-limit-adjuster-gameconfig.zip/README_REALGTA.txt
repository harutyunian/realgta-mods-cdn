=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : HeapAdjuster & Packfile Limit Adjuster + Gameconfig.xml (Unlimited Add-On Cars)
Slug        : heapadjuster-packfile-limit-adjuster-gameconfig
Game        : GTA V
Author      : DecompileGod
Version     : v1.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
