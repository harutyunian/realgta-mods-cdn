=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Menyoo PC v2.0 — Director Mode, Object Spooner & Vehicle Customizer
Game        : GTA V
Author      : AsphaltKilla
Version     : v1.8.1
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/MAFINS/MenyooSP/releases/tag/v1.8.1

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
