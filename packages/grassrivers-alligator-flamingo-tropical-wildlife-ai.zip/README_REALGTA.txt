=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Grassrivers Alligator, Flamingo & Tropical Wildlife Ecosystem AI
Slug        : grassrivers-alligator-flamingo-tropical-wildlife-ai
Game        : GTA VI
Author      : CrankHandle
Version     : v1.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
