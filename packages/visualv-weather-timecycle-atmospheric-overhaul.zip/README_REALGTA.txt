=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : VisualV v1.0.590 — Complete Weather, Timecycle & Atmospheric Overhaul
Slug        : visualv-weather-timecycle-atmospheric-overhaul
Game        : GTA V
Author      : GraphicsGod
Version     : v1.0.590
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
