=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : LA Revo 2.0 & Real California Architecture 4K Landmarks Overhaul
Slug        : la-revo-2-0-real-california-architecture-landmarks-gta-v
Game        : GTA V
Author      : CartoGamer
Version     : v2.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
