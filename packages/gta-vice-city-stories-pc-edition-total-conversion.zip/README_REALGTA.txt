=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA: Vice City Stories PC Edition Total Conversion (VCS PC)
Slug        : gta-vice-city-stories-pc-edition-total-conversion
Game        : GTA VC
Author      : TommyV_Ret
Version     : v1.3
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
