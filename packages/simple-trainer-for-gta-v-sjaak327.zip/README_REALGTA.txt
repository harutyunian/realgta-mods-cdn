=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Simple Trainer for GTA V v16.4 (sjaak327) — 800+ Functions & Teleport Menu
Slug        : simple-trainer-for-gta-v-sjaak327
Game        : GTA V
Author      : AlexanderBlade_Retro
Version     : v16.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
