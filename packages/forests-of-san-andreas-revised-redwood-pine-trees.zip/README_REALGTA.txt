=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Forests of San Andreas: Revised — 15,000+ Redwood & Pine Trees Map Mod
Slug        : forests-of-san-andreas-revised-redwood-pine-trees
Game        : GTA V
Author      : CartoGamer
Version     : v4.2
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
