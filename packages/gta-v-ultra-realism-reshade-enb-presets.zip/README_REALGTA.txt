=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Gta V Ultra Realism Reshade Enb Presets
Slug        : gta-v-ultra-realism-reshade-enb-presets
Game        : GTA V / SA / IV
Author      : RealGTA Community
Version     : v1.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
