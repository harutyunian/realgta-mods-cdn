=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Simple Native Trainer for GTA IV v6.5 (sjaak327) — Complete Control Suite
Slug        : simple-native-trainer-gta-iv-sjaak327
Game        : GTA IV
Author      : AlexanderBlade_Retro
Version     : v6.5
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
