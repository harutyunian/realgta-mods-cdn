=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Liberty Extended v2.1 — Full In-Game Map Menu, Swimming & Cut Content
Slug        : liberty-extended-ingame-map-swimming-cut-content-gta-3
Game        : GTA III
Author      : SnowFall99
Version     : v2.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
