=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Custom Gear & Manual Transmission + Steering Wheel Support (ikt)
Slug        : manual-transmission-steering-wheel-support-ikt-gta-v
Game        : GTA V
Author      : AsphaltKilla
Version     : v5.8.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
