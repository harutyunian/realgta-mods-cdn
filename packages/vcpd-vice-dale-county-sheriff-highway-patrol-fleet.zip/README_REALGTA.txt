=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : VCPD Vice-Dale County Sheriff & Florida Highway Patrol Fleet Pack
Slug        : vcpd-vice-dale-county-sheriff-highway-patrol-fleet
Game        : GTA VI
Author      : LeonidaSheriff
Version     : v2.2
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
