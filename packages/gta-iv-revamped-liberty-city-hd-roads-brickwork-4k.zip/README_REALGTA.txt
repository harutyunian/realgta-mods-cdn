=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA IV Revamped Liberty City HD Roads, Sidewalks & Brickwork 4K
Slug        : gta-iv-revamped-liberty-city-hd-roads-brickwork-4k
Game        : GTA IV
Author      : CartoGamer
Version     : v3.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
