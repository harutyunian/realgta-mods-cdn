=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Project Props & Proper Fixes v2.5 — Full San Andreas Map & Vegetation Remaster
Slug        : project-props-proper-fixes-san-andreas-map-remaster
Game        : GTA SA
Author      : ModderCarl
Version     : v2.5
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
