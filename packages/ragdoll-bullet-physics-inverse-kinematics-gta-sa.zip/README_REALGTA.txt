=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Ragdoll Bullet Physics + Inverse Kinematics Overhaul for GTA San Andreas
Slug        : ragdoll-bullet-physics-inverse-kinematics-gta-sa
Game        : GTA SA
Author      : AsphaltKilla
Version     : v1.5
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
