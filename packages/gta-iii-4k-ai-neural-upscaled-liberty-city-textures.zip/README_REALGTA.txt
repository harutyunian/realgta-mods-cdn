=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA III 4K AI Neural Upscaled Liberty City Textures (Portland to Shoreside)
Slug        : gta-iii-4k-ai-neural-upscaled-liberty-city-textures
Game        : GTA III
Author      : GraphicsGod
Version     : v1.9
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
