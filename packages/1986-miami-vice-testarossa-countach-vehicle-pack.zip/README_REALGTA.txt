=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : 1986 Miami Vice Ferrari Testarossa & Lamborghini Countach LP500S Pack
Slug        : 1986-miami-vice-testarossa-countach-vehicle-pack
Game        : GTA VC
Author      : SynthWaveCop
Version     : v1.6
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
