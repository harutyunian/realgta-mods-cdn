=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : VehFuncs v2.4 (Junior_Djjr) — Animated Engine Parts, Digital Dials & Exhausts
Slug        : vehfuncs-v2-4-animated-engine-parts-dials-gta-sa
Game        : GTA SA
Author      : MafiaDon
Version     : v2.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
