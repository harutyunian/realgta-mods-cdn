=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : SA_DirectX 3.0 — Next-Gen Ray-Marched Clouds, GI & Water Shaders for GTA SA
Slug        : sa-directx-3-0-raymarched-clouds-water-shaders-gta-sa
Game        : GTA SA
Author      : GraphicsGod
Version     : v3.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
