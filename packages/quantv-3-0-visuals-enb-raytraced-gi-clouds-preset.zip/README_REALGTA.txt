=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : QuantV 3.0 Visuals, ENB Ray-Traced GI & Volumetric Clouds Preset
Slug        : quantv-3-0-visuals-enb-raytraced-gi-clouds-preset
Game        : GTA V
Author      : GraphicsGod
Version     : v3.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
