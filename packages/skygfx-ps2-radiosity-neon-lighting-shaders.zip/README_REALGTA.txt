=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : SkyGfx v4.2b — Accurate PS2 Radiosity & Neon Lighting Shaders
Game        : GTA SA
Author      : RayTracerIV
Version     : v4.2b
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/aap/skygfx/releases/tag/v4.2b

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
