=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Cj Hd Remastered Skin Clothing Pack
Slug        : cj-hd-remastered-skin-clothing-pack
Game        : GTA V / SA / IV
Author      : RealGTA Community
Version     : v1.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
