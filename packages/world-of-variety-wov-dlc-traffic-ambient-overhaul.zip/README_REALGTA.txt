=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : World of Variety (WoV) — DLC Traffic, Gang Turfs & Ambient Life Overhaul
Slug        : world-of-variety-wov-dlc-traffic-ambient-overhaul
Game        : GTA V
Author      : CrankHandle
Version     : v6.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
