=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : CLEO 4.4 / 5.0 Library for GTA: San Andreas (Seemann & Alien)
Slug        : cleo-4-4-scripting-library-gta-san-andreas
Game        : GTA SA
Author      : DecompileGod
Version     : v4.4.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
