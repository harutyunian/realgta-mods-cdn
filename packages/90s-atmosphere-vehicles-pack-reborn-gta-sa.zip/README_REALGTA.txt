=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : 90s Atmosphere Vehicles Pack Reborn (160 Lore-Accurate SA Cars)
Slug        : 90s-atmosphere-vehicles-pack-reborn-gta-sa
Game        : GTA SA
Author      : MafiaDon
Version     : v3.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
