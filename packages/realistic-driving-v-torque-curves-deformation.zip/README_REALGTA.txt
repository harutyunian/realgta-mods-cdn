=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Realistic Driving V v1.9 — Real-World Speeds, Torque Curves & Deformation
Slug        : realistic-driving-v-torque-curves-deformation
Game        : GTA V
Author      : AsphaltKilla
Version     : v1.9
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
