=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Vanillaworks Extended Pack — 150+ Lore-Friendly Add-On Vehicles
Slug        : vanillaworks-extended-150-lore-friendly-vehicles-gta-v
Game        : GTA V
Author      : MafiaDon
Version     : v3.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
