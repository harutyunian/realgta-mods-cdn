=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : DYOM v8.1 (Design Your Own Mission) — Custom Storyline Builder for GTA SA
Slug        : dyom-v8-1-design-your-own-mission-story-builder-gta-sa
Game        : GTA SA
Author      : ModderCarl
Version     : v8.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
