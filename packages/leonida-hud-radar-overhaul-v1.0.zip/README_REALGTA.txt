=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA VI Leonida Neon Radar & HUD Overhaul v1.0
Game        : GTA V
Author      : RealGTA Studio
Version     : v1.0
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/harutyunian/realgta-mods-cdn

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
