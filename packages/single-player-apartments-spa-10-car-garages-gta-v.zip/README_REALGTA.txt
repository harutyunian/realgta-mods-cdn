=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Single Player Apartments (SPA) + 10-Car Garage & Maze Bank CEO Offices
Slug        : single-player-apartments-spa-10-car-garages-gta-v
Game        : GTA V
Author      : CartoGamer
Version     : v1.11
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
