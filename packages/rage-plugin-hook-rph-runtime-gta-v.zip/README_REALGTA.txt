=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : RAGE Plugin Hook (RPH) Latest Runtime for GTA V & LSPDFR
Slug        : rage-plugin-hook-rph-runtime-gta-v
Game        : GTA V
Author      : LeonidaSheriff
Version     : v1.115
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
