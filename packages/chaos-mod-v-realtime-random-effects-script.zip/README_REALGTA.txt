=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Chaos Mod V v2.2 — 350+ Real-Time Random Effect Triggers (GitHub Official)
Game        : GTA V
Author      : CrankHandle
Version     : 2.2.1
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/gta-chaos-mod/ChaosModV/releases/tag/2.2.1

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
