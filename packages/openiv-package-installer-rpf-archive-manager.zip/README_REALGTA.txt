=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : OpenIV Package Installer & RPF Archive Manager (GTAV / GTAIV)
Slug        : openiv-package-installer-rpf-archive-manager
Game        : GTA V
Author      : DecompileGod
Version     : v4.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
