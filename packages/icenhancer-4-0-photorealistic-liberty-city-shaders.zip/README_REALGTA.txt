=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : iCEnhancer 4.0 Natural & Photorealistic Liberty City Shaders
Slug        : icenhancer-4-0-photorealistic-liberty-city-shaders
Game        : GTA IV
Author      : RayTracerIV
Version     : v4.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
