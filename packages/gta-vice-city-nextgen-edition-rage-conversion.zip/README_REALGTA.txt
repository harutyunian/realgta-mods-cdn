=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA: Vice City Nextgen Edition (Full RAGE Engine Total Conversion)
Slug        : gta-vice-city-nextgen-edition-rage-conversion
Game        : GTA VC
Author      : TommyV_Ret
Version     : v1.1
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
