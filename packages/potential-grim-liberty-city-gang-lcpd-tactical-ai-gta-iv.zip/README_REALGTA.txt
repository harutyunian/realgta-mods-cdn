=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Potential Grim — Smarter Liberty City Gang & LCPD Tactical Shootout AI
Slug        : potential-grim-liberty-city-gang-lcpd-tactical-ai-gta-iv
Game        : GTA IV
Author      : CrankHandle
Version     : v1.9
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
