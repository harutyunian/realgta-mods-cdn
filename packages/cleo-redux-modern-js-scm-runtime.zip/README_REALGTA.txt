=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : CLEO Redux v1.1.4 — Modern JS & SCM Scripting Runtime
Game        : GTA VC
Author      : DecompileGod
Version     : 1.5.1
Official Hub: https://realgta.com/mods
Upstream URL: https://github.com/cleolibrary/CLEO-Redux/releases/tag/1.5.1

INSTALLATION INSTRUCTIONS:
1. Ensure ScriptHookV / OpenIV / ASI Loader is installed in your GTA directory.
2. Copy the configuration/script files or open Upstream_Release_Link.url for the full binary archive.
3. Troubleshooting ERR_GFX_D3D_INIT or 188 FPS Stutter:
   - https://realgta.com/articles/how-to-fix-err-gfx-d3d-init-and-gameconfig-crash-gta-5
   - https://realgta.com/articles/why-does-gta-5-stutter-at-high-fps
