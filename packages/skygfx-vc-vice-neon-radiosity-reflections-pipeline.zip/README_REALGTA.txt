=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : SkyGfx VC & Vice Neon Radiosity Reflections Pipeline v3.7
Slug        : skygfx-vc-vice-neon-radiosity-reflections-pipeline
Game        : GTA VC
Author      : RayTracerIV
Version     : v3.7
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
