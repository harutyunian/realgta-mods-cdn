=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA VI Leonida Keys & Overseas Highway 7-Mile Bridge Map Pack
Slug        : gta-vi-leonida-keys-overseas-highway-7-mile-bridge-map
Game        : GTA VI
Author      : LeonidaMapper
Version     : v1.4
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
