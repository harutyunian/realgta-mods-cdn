=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : Port Gellhorn & Grassrivers Everglades Airboat Physics Pack
Slug        : port-gellhorn-grassrivers-everglades-airboat-pack
Game        : GTA VI
Author      : AsphaltKilla
Version     : v1.3
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
