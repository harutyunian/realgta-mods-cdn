=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GInput v1.11 (Silent) — Native XInput Xbox & DualShock Controller Prompts
Slug        : ginput-silent-xinput-xbox-playstation-controller-support
Game        : GTA SA
Author      : CookiePLMonster
Version     : v1.11
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
