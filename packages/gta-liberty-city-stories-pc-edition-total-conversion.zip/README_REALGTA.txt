=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : GTA: Liberty City Stories PC Edition (LCS PC Total Conversion)
Slug        : gta-liberty-city-stories-pc-edition-total-conversion
Game        : GTA III
Author      : SnowFall99
Version     : v5.0
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
