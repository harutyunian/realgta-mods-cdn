=================================================================
  REALGTA.COM — OFFICIAL VERIFIED MOD PACKAGE
=================================================================
Mod Title   : LSPD First Response (LSPDFR 0.4.9) — Complete Police Simulation Total Conversion
Slug        : lspdfr-police-simulation-total-conversion-mod
Game        : GTA V
Author      : LeonidaSheriff
Version     : v0.4.9
Official Hub: https://realgta.com/mods

INSTALLATION:
1. Extract the contents of this archive into your GTA game folder (or /mods /scripts folder).
2. Ensure ScriptHookV / ASI Loader / CLEO is installed.
